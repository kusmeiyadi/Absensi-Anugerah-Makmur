<?php require '../config.php'; need('admin');
$t=date('Y-m-d');
$tot=$db->query("SELECT COUNT(*) FROM users WHERE aktif=1 AND role='staff'")->fetchColumn();
$q=$db->prepare("SELECT status,COUNT(*) c FROM absensi WHERE tanggal=? GROUP BY status");$q->execute([$t]);$c=array_column($q->fetchAll(),'c','status');
$hadir=($c['hadir']??0)+($c['terlambat']??0);
$q=$db->prepare('SELECT a.*,u.nama FROM absensi a JOIN users u ON u.id=a.user_id WHERE tanggal=? ORDER BY jam_masuk');$q->execute([$t]);
head('Dashboard');?>
<h1 class="text-xl font-bold text-yellow-900 mb-3">Dashboard · <?=date('d-m-Y')?></h1>
<div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
<?php foreach([['Pegawai aktif',$tot],['Hadir',$hadir],['Terlambat',$c['terlambat']??0],['Belum absen',max(0,$tot-$hadir)]] as [$l,$v]):?>
 <div class="<?=CARD?> text-center"><p class="text-3xl font-bold text-yellow-700"><?=$v?></p><p class="text-sm text-stone-500"><?=$l?></p></div><?php endforeach;?></div>
<div class="<?=CARD?> overflow-x-auto"><h2 class="font-semibold mb-2">Absensi hari ini</h2>
<table class="w-full text-sm"><tr class="text-left text-stone-500"><th>Nama</th><th>Masuk</th><th>Pulang</th><th>Jarak</th><th>Status</th><th>Foto</th></tr>
<?php foreach($q as $r):?><tr class="border-t border-yellow-100"><td class="py-1"><?=e($r['nama'])?></td><td><?=substr($r['jam_masuk'],0,5)?></td><td><?=$r['jam_pulang']?substr($r['jam_pulang'],0,5):'-'?></td><td><?=$r['jarak_masuk']?> m</td>
<td><span class="px-2 py-0.5 rounded-full text-xs <?=$r['status']==='hadir'?'bg-green-100 text-green-700':'bg-orange-100 text-orange-700'?>"><?=$r['status']?></span></td>
<td><?php foreach(['foto_masuk','foto_pulang'] as $k)if($r[$k])echo '<a class="text-yellow-700 underline mr-1" target="_blank" href="'.BASE.'/uploads/'.e($r[$k]).'">'.($k==='foto_masuk'?'masuk':'pulang').'</a>';?></td></tr><?php endforeach;?></table></div>
<?php foot();
