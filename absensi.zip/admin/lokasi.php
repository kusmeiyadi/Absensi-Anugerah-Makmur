<?php require '../config.php'; need('admin');
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){cek_csrf();
 $db->prepare('UPDATE settings SET nama_kantor=?,lat=?,lng=?,radius=?,jam_masuk=? WHERE id=1')->execute([trim($_POST['nama']),(float)$_POST['lat'],(float)$_POST['lng'],max(10,(int)$_POST['radius']),$_POST['jam']]);
 $msg='Pengaturan tersimpan.';}
$s=$db->query('SELECT * FROM settings WHERE id=1')->fetch();
head('Lokasi Kantor');?>
<h1 class="text-xl font-bold text-yellow-900 mb-3">Lokasi & Jam Kantor</h1>
<?php if($msg):?><div class="mb-3 p-2 rounded-lg bg-yellow-100 text-sm"><?=e($msg)?></div><?php endif;?>
<form method="post" class="<?=CARD?> max-w-lg space-y-3"><?=csrf()?>
 <label class="block text-sm">Nama kantor<input name="nama" value="<?=e($s['nama_kantor'])?>" class="<?=INP?>"></label>
 <div class="grid grid-cols-2 gap-3">
  <label class="block text-sm">Latitude<input id="lat" name="lat" value="<?=$s['lat']?>" class="<?=INP?>"></label>
  <label class="block text-sm">Longitude<input id="lng" name="lng" value="<?=$s['lng']?>" class="<?=INP?>"></label></div>
 <button type="button" onclick="navigator.geolocation.getCurrentPosition(p=>{lat.value=p.coords.latitude.toFixed(7);lng.value=p.coords.longitude.toFixed(7)},()=>alert('Gagal membaca GPS'),{enableHighAccuracy:true})" class="text-sm underline text-yellow-800">📍 Gunakan lokasi saya sekarang</button>
 <div class="grid grid-cols-2 gap-3">
  <label class="block text-sm">Radius (meter)<input name="radius" type="number" value="<?=$s['radius']?>" class="<?=INP?>"></label>
  <label class="block text-sm">Jam masuk<input name="jam" type="time" value="<?=substr($s['jam_masuk'],0,5)?>" class="<?=INP?>"></label></div>
 <button class="<?=BTN?>">Simpan</button></form>
<?php foot();
