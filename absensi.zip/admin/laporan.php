<?php require '../config.php'; need('admin');
$d1=$_GET['dari']??date('Y-m-01');$d2=$_GET['sampai']??date('Y-m-d');$uid=(int)($_GET['u']??0);
$sql='SELECT a.*,u.nama FROM absensi a JOIN users u ON u.id=a.user_id WHERE a.tanggal BETWEEN ? AND ?'.($uid?' AND a.user_id=?':'').' ORDER BY a.tanggal DESC,u.nama';
$q=$db->prepare($sql);$q->execute($uid?[$d1,$d2,$uid]:[$d1,$d2]);$rows=$q->fetchAll();
if(isset($_GET['csv'])){header('Content-Type: text/csv');header('Content-Disposition: attachment; filename=laporan-absensi.csv');$o=fopen('php://output','w');
 fputcsv($o,['Tanggal','Nama','Masuk','Pulang','Jarak Masuk (m)','Status']);
 foreach($rows as $r)fputcsv($o,[$r['tanggal'],$r['nama'],$r['jam_masuk'],$r['jam_pulang'],$r['jarak_masuk'],$r['status']]);exit;}
$us=$db->query('SELECT id,nama FROM users ORDER BY nama')->fetchAll();
head('Laporan');?>
<h1 class="text-xl font-bold text-yellow-900 mb-3">Laporan Absensi</h1>
<form class="<?=CARD?> flex flex-wrap gap-3 items-end mb-4">
 <label class="text-sm">Dari<input type="date" name="dari" value="<?=e($d1)?>" class="<?=INP?>"></label>
 <label class="text-sm">Sampai<input type="date" name="sampai" value="<?=e($d2)?>" class="<?=INP?>"></label>
 <label class="text-sm">Pegawai<select name="u" class="<?=INP?>"><option value="0">Semua</option><?php foreach($us as $x)echo '<option value="'.$x['id'].'" '.($x['id']==$uid?'selected':'').'>'.e($x['nama']).'</option>';?></select></label>
 <button class="<?=BTN?>">Tampilkan</button>
 <button name="csv" value="1" class="rounded-lg border border-yellow-400 px-4 py-2 hover:bg-yellow-100">Unduh CSV</button></form>
<div class="<?=CARD?> overflow-x-auto"><table class="w-full text-sm"><tr class="text-left text-stone-500"><th>Tanggal</th><th>Nama</th><th>Masuk</th><th>Pulang</th><th>Jarak</th><th>Status</th><th>Foto</th><th>Peta</th></tr>
<?php foreach($rows as $r):?><tr class="border-t border-yellow-100"><td class="py-1"><?=date('d-m-Y',strtotime($r['tanggal']))?></td><td><?=e($r['nama'])?></td><td><?=substr($r['jam_masuk'],0,5)?></td><td><?=$r['jam_pulang']?substr($r['jam_pulang'],0,5):'-'?></td><td><?=$r['jarak_masuk']?> m</td><td><?=$r['status']?></td>
<td><?php foreach(['foto_masuk'=>'masuk','foto_pulang'=>'pulang'] as $k=>$l)if($r[$k])echo '<a class="text-yellow-700 underline mr-1" target="_blank" href="'.BASE.'/uploads/'.e($r[$k]).'">'.$l.'</a>';?></td>
<td><a class="text-yellow-700 underline" target="_blank" href="https://www.google.com/maps?q=<?=$r['lat_masuk'].','.$r['lng_masuk']?>">lihat</a></td></tr><?php endforeach;?>
<?php if(!$rows)echo '<tr><td colspan="8" class="py-4 text-center text-stone-400">Tidak ada data.</td></tr>';?></table></div>
<?php foot();
