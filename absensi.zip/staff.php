<?php require 'config.php'; need();
$u=user();$s=$db->query('SELECT * FROM settings WHERE id=1')->fetch();
function simpanFoto($f){
 if(!$f||$f['error']===UPLOAD_ERR_NO_FILE)return null;
 if($f['error']!==0||$f['size']>4*1048576)throw new Exception('Foto gagal diunggah (maks 4MB).');
 $i=@getimagesize($f['tmp_name']);$ext=[IMAGETYPE_JPEG=>'jpg',IMAGETYPE_PNG=>'png',IMAGETYPE_WEBP=>'webp'][$i[2]??0]??null;
 if(!$ext)throw new Exception('Format foto harus JPG/PNG/WEBP.');
 $n=bin2hex(random_bytes(8)).'.'.$ext;move_uploaded_file($f['tmp_name'],__DIR__.'/uploads/'.$n);return $n;}
if($_SERVER['REQUEST_METHOD']==='POST'){
 header('Content-Type: application/json');
 try{
  if(!hash_equals($_SESSION['csrf'],$_POST['csrf']??''))throw new Exception('Sesi tidak valid, muat ulang halaman.');
  $lat=filter_var($_POST['lat']??'',FILTER_VALIDATE_FLOAT);$lng=filter_var($_POST['lng']??'',FILTER_VALIDATE_FLOAT);
  if($lat===false||$lng===false)throw new Exception('Lokasi GPS belum terbaca.');
  $j=(int)round(jarak($lat,$lng,$s['lat'],$s['lng']));
  if($j>$s['radius'])throw new Exception("Anda berada $j m dari kantor (maksimal {$s['radius']} m).");
  $tgl=date('Y-m-d');$now=date('H:i:s');
  $q=$db->prepare('SELECT * FROM absensi WHERE user_id=? AND tanggal=?');$q->execute([$u['id'],$tgl]);$a=$q->fetch();
  $aksi=$_POST['aksi']??'';
  if($aksi==='masuk'){
   if($a)throw new Exception('Anda sudah absen masuk hari ini.');
   $f=simpanFoto($_FILES['foto']??null);$st=$now>$s['jam_masuk']?'terlambat':'hadir';
   $db->prepare('INSERT INTO absensi(user_id,tanggal,jam_masuk,lat_masuk,lng_masuk,jarak_masuk,foto_masuk,status) VALUES(?,?,?,?,?,?,?,?)')->execute([$u['id'],$tgl,$now,$lat,$lng,$j,$f,$st]);
   $m="Absen masuk berhasil pukul ".substr($now,0,5).($st==='terlambat'?' (terlambat)':'').'.';
  }elseif($aksi==='pulang'){
   if(!$a)throw new Exception('Anda belum absen masuk.');
   if($a['jam_pulang'])throw new Exception('Anda sudah absen pulang.');
   $f=simpanFoto($_FILES['foto']??null);
   $db->prepare('UPDATE absensi SET jam_pulang=?,lat_pulang=?,lng_pulang=?,jarak_pulang=?,foto_pulang=? WHERE id=?')->execute([$now,$lat,$lng,$j,$f,$a['id']]);
   $m='Absen pulang berhasil pukul '.substr($now,0,5).'.';
  }else throw new Exception('Aksi tidak dikenal.');
  echo json_encode(['ok'=>1,'msg'=>$m]);
 }catch(Exception $e){http_response_code(400);echo json_encode(['ok'=>0,'msg'=>$e->getMessage()]);}
 exit;}
$q=$db->prepare('SELECT * FROM absensi WHERE user_id=? AND tanggal=?');$q->execute([$u['id'],date('Y-m-d')]);$a=$q->fetch();
$h=$db->prepare('SELECT * FROM absensi WHERE user_id=? ORDER BY tanggal DESC LIMIT 10');$h->execute([$u['id']]);
head('Absen Saya');?>
<div class="max-w-xl mx-auto space-y-4">
 <div class="<?=CARD?> text-center">
  <p class="text-sm text-stone-500"><?=e($s['nama_kantor'])?> · radius <?=$s['radius']?> m · jam masuk <?=substr($s['jam_masuk'],0,5)?></p>
  <p id="jam" class="text-4xl font-bold text-yellow-800 my-1">--:--:--</p>
  <p class="text-sm"><?=date('d-m-Y')?></p>
  <div id="gps" class="mt-3 text-sm rounded-lg bg-yellow-100 p-2">Membaca lokasi GPS…</div>
 </div>
 <div class="<?=CARD?> space-y-3">
  <p class="text-sm">Status hari ini: <b><?=!$a?'Belum absen':'Masuk '.substr($a['jam_masuk'],0,5).($a['jam_pulang']?' · Pulang '.substr($a['jam_pulang'],0,5):'')?></b></p>
  <label class="block text-sm">Foto selfie <span class="text-stone-400">(opsional)</span>
   <input id="foto" type="file" accept="image/*" capture="user" class="<?=INP?> mt-1 text-sm"></label>
  <div class="grid grid-cols-2 gap-3">
   <button onclick="absen('masuk')" class="<?=BTN?> disabled:opacity-40" <?=$a?'disabled':''?>>Absen Masuk</button>
   <button onclick="absen('pulang')" class="<?=BTN?> disabled:opacity-40" <?=(!$a||$a['jam_pulang'])?'disabled':''?>>Absen Pulang</button>
  </div>
  <div id="msg" class="hidden text-sm p-2 rounded-lg"></div>
 </div>
 <div class="<?=CARD?>"><h2 class="font-semibold mb-2">Riwayat 10 hari terakhir</h2>
  <table class="w-full text-sm"><tr class="text-left text-stone-500"><th>Tanggal</th><th>Masuk</th><th>Pulang</th><th>Status</th></tr>
  <?php foreach($h as $r):?><tr class="border-t border-yellow-100"><td class="py-1"><?=date('d-m-Y',strtotime($r['tanggal']))?></td><td><?=substr($r['jam_masuk'],0,5)?></td><td><?=$r['jam_pulang']?substr($r['jam_pulang'],0,5):'-'?></td><td><?=$r['status']?></td></tr><?php endforeach;?></table></div>
</div>
<script>
const O={lat:<?=(float)$s['lat']?>,lng:<?=(float)$s['lng']?>,r:<?=(int)$s['radius']?>};
const hav=(a,b,c,d)=>{const p=Math.PI/180,x=Math.sin((c-a)*p/2)**2+Math.cos(a*p)*Math.cos(c*p)*Math.sin((d-b)*p/2)**2;return 2*6371000*Math.asin(Math.sqrt(x))};
setInterval(()=>jam.textContent=new Date().toLocaleTimeString('id-ID',{timeZone:'Asia/Pontianak',hour12:false}),1000);
const gpsErr=()=>gps.textContent='GPS tidak aktif / izin lokasi ditolak. Aktifkan lokasi lalu muat ulang.';
if(navigator.geolocation)navigator.geolocation.watchPosition(p=>{const j=Math.round(hav(p.coords.latitude,p.coords.longitude,O.lat,O.lng)),ok=j<=O.r;
 gps.className='mt-3 text-sm rounded-lg p-2 '+(ok?'bg-green-100 text-green-800':'bg-red-100 text-red-700');
 gps.textContent=(ok?'✅ Dalam area kantor':'❌ Di luar area kantor')+' · jarak '+j+' m (akurasi ±'+Math.round(p.coords.accuracy)+' m)';},gpsErr,{enableHighAccuracy:true});else gpsErr();
function show(t,ok){msg.className='text-sm p-2 rounded-lg '+(ok?'bg-green-100 text-green-800':'bg-red-100 text-red-700');msg.textContent=t}
function absen(aksi){show('Memproses…',true);
 navigator.geolocation.getCurrentPosition(async p=>{
  const fd=new FormData();fd.append('aksi',aksi);fd.append('csrf','<?=$_SESSION['csrf']?>');fd.append('lat',p.coords.latitude);fd.append('lng',p.coords.longitude);
  if(foto.files[0])fd.append('foto',foto.files[0]);
  try{const r=await fetch('staff.php',{method:'POST',body:fd}),d=await r.json();show(d.msg,d.ok);if(d.ok)setTimeout(()=>location.reload(),1200)}catch(e){show('Gagal menghubungi server.',false)}
 },()=>show('Gagal membaca GPS. Izinkan akses lokasi.',false),{enableHighAccuracy:true,timeout:15000});}
</script><?php foot();
